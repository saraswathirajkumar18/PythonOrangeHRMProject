from selenium import webdriver
from selenium.webdriver.common.by import By


class Login:
    # create variables to store loginpage username,password,login button element's name and locator value.
    textbox_username_name = "username"
    textbox_password_name = "password"
    button_login_xpath = "//button[@type='submit']"

    # initialise driver using constructor
    def __init__(self, driver):
        self.driver = driver

    # find username text box,clear content, insert value in it.
    def setUserName(self, username):
        self.driver.find_element(By.NAME, self.textbox_username_name).clear()
        self.driver.find_element(By.NAME, self.textbox_username_name).send_keys(username)

    # find password text box,clear content, insert value in it.
    def setPassword(self, password):
        self.driver.find_element(By.NAME, self.textbox_password_name).clear()
        self.driver.find_element(By.NAME, self.textbox_password_name).send_keys(password)

    # find login button then perform click operation.
    def clickLoginButton(self):
        self.driver.find_element(By.XPATH, self.button_login_xpath).click()
