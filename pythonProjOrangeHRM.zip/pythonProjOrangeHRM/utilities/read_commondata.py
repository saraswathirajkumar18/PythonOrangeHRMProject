import configparser

# create obj used to access data from config.ini file
config = configparser.RawConfigParser()
# mention common data file name
config.read("C:\\Users\\krajk\\PycharmProjects\\pythonProjOrangeHRM\\Configurations\\config.ini")


class ReadConfigData:
    # method to return url info
    @staticmethod
    def get_appurl():
        app_url = config.get('common data', 'url')
        #print(app_url)
        return app_url

    # method to return username info
    @staticmethod
    def get_username():
        uname = config.get('common data', 'username')
        #print(uname)
        return uname

    # method to return username info
    @staticmethod
    def get_password():
        userpass = config.get('common data', 'password')
        #print(userpass)
        return userpass



