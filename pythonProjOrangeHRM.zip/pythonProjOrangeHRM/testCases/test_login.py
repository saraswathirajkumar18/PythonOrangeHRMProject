import pytest
from selenium import webdriver
from pageObjects.login_page import Login
from utilities.read_commondata import ReadConfigData
import time

class Test_001_Login:
    #get url ,username,password data by calling methods in read_commondata.py
    url = ReadConfigData.get_appurl()
    username = ReadConfigData.get_username()
    password = ReadConfigData.get_password()

#create test function for login testcase with browser serup argument
    def test_login(self,browser_setup):
        #launch browser
        self.driver = browser_setup
        #set url
        self.driver.get(self.url)
        #maximize browser
        self.driver.maximize_window()
        #delay execution
        time.sleep(3)
        #Create object for Login class
        self.login_page_obj = Login(self.driver)
        #call setUsername method in login_page.py
        self.login_page_obj.setUserName(self.username)
        # call setPassword method in login_page.py
        self.login_page_obj.setPassword(self.password)
        # call clickLoginButton method in login_page.py
        self.login_page_obj.clickLoginButton()
        #get current url
        actual_url = self.driver.current_url
        #print("result", actual_url)

        #check actual_url with desired value

        if actual_url == "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index":
            self.driver.close()
            assert True

        else:
            #if testcase fails then take screenshot and store it.
            self.driver.save_screenshot("C:\\Users\\krajk\\PycharmProjects\\pythonProjOrangeHRM\\Screenshots\\login_test.png")
            time.sleep(2)
            #close the driver
            self.driver.close()
            assert False
