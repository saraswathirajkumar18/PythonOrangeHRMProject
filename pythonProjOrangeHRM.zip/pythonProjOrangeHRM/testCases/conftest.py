from selenium import webdriver
import pytest
from pytest_metadata.plugin import metadata_key

#run before each test method
@pytest.fixture()
def browser_setup():
    #intialise webdriver as chrome
    driver = webdriver.Chrome()
    return driver

#add project details for test html reports
def pytest_configure(config):
    config.stash[metadata_key]["Project Name"] = "Orange HRM"
    config.stash[metadata_key]["Module Name"] = "Login Page"
    config.stash[metadata_key]["Tester"] = "Saraswathi"



